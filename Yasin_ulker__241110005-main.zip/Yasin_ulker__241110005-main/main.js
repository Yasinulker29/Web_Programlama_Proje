document.getElementById("toggle-button").addEventListener("click", function() {
    var extraContent = document.getElementById("extra-content");
    
    
    if (extraContent.style.display === "none") {
        extraContent.style.display = "block";
        this.textContent = "Daha Az Göster"; r
    } else {
        extraContent.style.display = "none";
        this.textContent = "Daha Fazla Göster"; 
    }
});